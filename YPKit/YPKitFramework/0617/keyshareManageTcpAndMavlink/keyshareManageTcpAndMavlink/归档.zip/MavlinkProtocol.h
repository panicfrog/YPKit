//
//  keyshareManageTcpAndMavlink.h
//  BLE_KEYSHARE
//
//  Created by keyshare-maoxue on 15/12/22.
//  Copyright © 2015年 keyshare-maoxue. All rights reserved.
//



#import <Foundation/Foundation.h>

#define CONN_LOSE_TIME   5

@interface MavlinkProtocol : NSObject
#pragma mark 通信数据

@property  uint32_t custom_mode;
@property  float    alt;

@property  uint8_t  num_stat;
@property double latitude;
@property double longitude;
@property float ground_speed;

@property float roll;
@property float pitch;
@property float yaw;



@property double home_latitude;
@property double home_longitude;


@property (nonatomic,strong) NSString* warText;


//返回的相关参数的值
@property float wpnav_loit_speed;
@property float fence_Alt;
@property float fence_Radius;
@property float fence_Action;
@property float rtl_Alt;
@property float fs_Batt;
@property float fs_Thr;
@property float fs_Enable;

@property  uint8_t isConnFightSystem;           //和飞控连接是否是有效连接

#pragma mark 单例模式实现
+(MavlinkProtocol *)shareManage;

#pragma mark 应用函数

-(void)connect: (NSString *) hostIP port:(int) hostPort;
-(void)disConnect;

//请求家的位置
-(void)request_Home;

//自稳
-(void)stab;
//悬停
-(void)loiter;
//返航
-(void)rtl;
//着陆
-(void)land;
//请求数据流
-(void)request_Data_Stream;
//解锁
-(void)arm;
//指导
-(void)guide;
//自动
-(void)auto;

//设置参数
-(void)setParam:(float)m_wp_Loiter_Speed _fence_Alt:(float)m_fence_Alt _fence_Radio:(float)m_fence_Radio _fence_Action:(float)m_fence_Action _rtl_Alt:(float)m_rtl_Alt _fs_Batt:(float)m_fs_Batt  _fs_Thr:(float)m_fs_Thr _fence_Enable:(float)m_fence_Enable;

//读取参数
-(void)readParam;



//启动航迹
-(void)startMission;

//写入航迹
-(void)writeMission:(NSMutableArray *) mission;

//读取航点
-(void)readMission;



//读取航点返回的block
@property (nonatomic,strong)void (^returnCurrentMission)(NSMutableArray *currentMission,int count);

#pragma mark 加速度六面校准部份
//开启accel校准
-(void)openAccelCali;
-(void)accel_Cali_Step:(int)count;

@property (nonatomic,strong)void (^connectRes)(NSInteger);


@end


